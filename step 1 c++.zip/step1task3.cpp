//TASK 3-----------------------------------------------------------------------------------------------------------------------------

/*
#include <iostream> // Preprocessor directives
#include <iomanip>
using namespace std;
int main()  // substituted 'void' for 'int'
{
	// Define and initialize variables
	int hoursPerWeek = 35;
	double hourlyWages = 83;
	double weeklyWages;  //needed to be declared
	// Calculate weekly salary
	weeklyWages = hoursPerWeek * hourlyWages;
	// Display results
	cout << fixed // Floating point format
		<< setprecision(2) // 2 decimals
		<< showpoint; // Show trailing zero�es
	cout << " Given an hourly wage of " << hourlyWages << " kr" << endl
		<< " and the number of hours per week " << hoursPerWeek << endl
		<< "the weekly wages will be: " << weeklyWages << " kr" << endl; // ';' was missing
	cout << "\nPress return!";
	cin.get(); // Wait for return
	return 0;
}
*/