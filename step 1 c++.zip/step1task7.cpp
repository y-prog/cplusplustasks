//task 7------------------------------------------------------------------------------------------------

/*
#include <iostream>
#include <iomanip>
using namespace std;



int main()
{
	int remtime;
	int hours, min;
	int rest;
	const int TIME = 60;
	int km;
	int remdistance;

	char answer;
	do
	{
		cout << "input average speed (kmh):";		cin >> km;
		// Calculation
		//hours = time / 60;
		//rest = time % 60;
		//min = rest;

		//input
		cout << "input remaining distance (swedish miles)";
		cin >> remdistance;



		//	Calculation remaining time
		remtime = int(TIME * remdistance * 10) / (km);
		cout << "Calculated	remaining time	:	" << remtime / 60 << ':' << remtime % 60 << endl;

		cout << "\n\nNew calculation (Y/N)?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');

	return 0;
}
*/
