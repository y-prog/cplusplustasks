
//TASK 4-----------------------------------------------------------------------------------------------------------------------
//	Preprocessor	directives
/*
#include <iostream>
#include <iomanip>
using namespace std;
// Prototypes

void priceCalculation();

int main()
{
	char answer;
	do
	{
		priceCalculation();
		cout << "One more time (Y/N) ? ";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y'); // one more '=' was missing
	return 0;
}


//
// Summary: Reads price and number of articles from user. Calculates and prints
// quantity, vat and price with vat
// Returns: -
//-----------------------------------------------------------------
void priceCalculation()
{
	// Define and initialize constants and variables
	const int RATE = 25; // tax rate in percent
	double price = 0; // price per piece
	int nrOfArticles = 0; // number of articles

	double rateSEK = 0; // tax rate in SEK
	double totalPrice = 0; // price incl. tax rate
	// Read price and number of articles
	cout << "Enter the price excl. the tax rate (swedish moms): ";
	cin >> price;
	cout << "Enter the number of articles: ";
	cin >> nrOfArticles;
	// Calculate total price and tax rate
	rateSEK = totalPrice * RATE;
	totalPrice = nrOfArticles * price *(1 + RATE);
	// Display result with 2 decimals
	cout << fixed << showpoint << setprecision(2);
	cout << nrOfArticles << " number of articles cost " << totalPrice << " kr. "
		<< endl << "Of this " << rateSEK << " kr is the tax rate." << endl;
}
*/