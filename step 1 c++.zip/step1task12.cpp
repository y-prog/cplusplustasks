//task 12 -------------------------------------------------------------------------------------------------
/*
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;

int main()
{
	int temp;
	int windspeed;
	int efftemp;
	const double EXP = 0.16;

	char answer;
	do
	{
		cout << "input temperature in Celsius";
		cin >> temp;
		cout << "input windspeed in m/s";
		cin >> windspeed;

		//calculation
		efftemp = int(13.126667 + 0.6215*temp - 13.924748*pow(windspeed, EXP) + 0.4875195*temp*pow(windspeed, EXP));
		cout << "rounded effective temperature = " << setprecision(0) << efftemp << " C " << endl;

		cout << "new calculation (Y/N)?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');

	return 0;


}
*/