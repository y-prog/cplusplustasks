//TASK 9------------------------------------------------------------------------------------------------------
/*
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	const int REFPOWER = 20;
	int power;
	int db;

	cout << "input power";
	cin >> power;

	//calculation

	db = int(10 * log10(power / REFPOWER));
	cout << " a change from " << REFPOWER << " to " << power << " corresponds to " << db << " db" <<
		". that is " << db / 3 << " range of 3db" << endl;
	return 0;
}

*/



