//TASK14----------------------------------------------------
/*
#include<iomanip>
#include<iostream>
#include<cmath>


using namespace std;

int main()
{
	double b;// initial amount
	int n;// number of years
	double fa; //final amount
	const int INTRATE = 3;
	double c;
	char answer;
	do
	{
		cout << "enter initial amount";
		cin >> b;
		cout << "enter number of years";
		cin >> n;

		//calculation
		c = 1 + (INTRATE / 100.0);
		fa = double(b*(pow(c, n)));
		cout << "the capital with " << INTRATE << "% interest rate and after " << n
			<< " years will be: " << fa << " SEK " << endl;

		cout << "new calculation (Y/N)?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');
	return 0;

}
*/