//TASK 10-------------------------------------------------------------------------------------------------
/*
#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;

int main()
{
	const int EXP = 2; //exponent = 2
	double x;
	double y;
	double z;

	char answer;
	do
	{

		cout << "input first cathetus";
		cin >> x;
		cout << "input second cathetus";
		cin >> y;

		//calculate hyp
		z = double(sqrt((pow(x, EXP)) + pow(y, EXP)));
		cout << "hypotenuse = " << setprecision(3) << z << endl; // 2 decimal places

		cout << "n\nNew calculation (Y/N)?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');


	return 0;

} 
*/