//TASK 13------------------------------------------------------------------------------------------
/*
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	double x; //starting capital
	double x1; // capital year 1
	double x2; //capital year 2
	double x3; //capital year 3
	double x4; //capital year 4
	double p1; //percentage year 1
	double p2; //percentage year 2
	double p3; //percentage year 3
	double p4; //percentage year 4

	char answer;
	do
	{
		cout << "input starting capital";
		cin >> x;
		cout << "input percentage year one";
		cin >> p1;
		cout << "input percentage year two";
		cin >> p2;
		cout << "input percentage year three";
		cin >> p3;
		cout << "input percentage year four";
		cin >> p4;

		//calculate

		x1 = double(x*(1 + p1 / 100));
		x2 = double(x1*(1 + p2 / 100));
		x3 = double(x2*(1 + p3 / 100));
		x4 = double(x3*(1 + p4 / 100));

		cout << "capital year 4 = " << x4 << endl;

		cout << "new calculation(Y/N)?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');

	return 0;
}
*/