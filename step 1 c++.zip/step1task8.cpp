//task 8---------------------------------------------------------------------------------------------------------
/*
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	double price;
	double payment;
	int rest;
	int totalrest;


		cout << "input payment in sek";
		cin >> payment;
		cout << "input price";
		cin >> price;

		//calculate rest
		rest = int((payment - price)*100); // rest in ore
		totalrest = int(payment - price); //rest in SEK

		cout << "total rest:" << setprecision(0) << totalrest<<"-kr back";
		cout << "=======================\n";

		cout << "calculate rest:" << rest/100000 << "-pieces of 1000," << rest%100000/50000 <<"-pieces of 500,"<<
			rest%50000/10000<<"-pieces of 100,"<<rest%10000/5000<<"-pieces of 50,"<<rest%5000/2000<<"-pieces of 20,"
			<<rest%2000/1000<<"-pieces of 10,"<<rest%1000/500<<"-pieces of 5,"<<rest%500/100<<"-pieces of 1."<< endl;

		return 0;
}
*/