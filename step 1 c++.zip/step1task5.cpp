//TASK 5--------------------------------------------------------------------------------------------------------------------
/*
#include <iostream>
#include <iomanip>
using namespace std;
//Prototypes
void temperature();
int main()
{
	char answer;
	do
	{
		temperature();
		cout << "One more time (Y/N) ?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');
	return 0;
}

void temperature()


{


	//	Definition	of	(local)	variables

	double farenheit;
	double celsius;
	//	Input
	cout << "farenheit-celsius\n" ;
	cout << "=========\n\n" ;
	cout << "Input	the temperature in farenheit:	" ;
	cin >> farenheit;

	//	Calculation
	celsius  = (farenheit - 30)*(5/9) ;// conversion formula
	//	Output
	cout << "======================\n";
	cout << "the temperature is	:	" << celsius << "	C" << endl;
	// Display results
	cout << setprecision(1);// 1 decimal


}
*/