//TASK 11---------------------------------------------------------------------------------------------------------
/*
#include<iostream>
#include<iomanip>
using namespace std;

int main()
{
	int x;
	int y;


	char answer;
	do
	{
		cout << "input a 3 digit number";
		cin >> x;

		//calculate

		y = int((x % 10) + (x / 10 % 10) + (x / 100 % 10));
		cout << "======== " << (x % 10) << " + " << (x / 10 % 10) << " + " << (x / 100 % 10) << "=" << y << endl;

		cout << "new calculation (Y/N)?";
		cin >> answer;

	} while (answer == 'Y' || answer == 'y');
	return 0;


}
*/