
//task 6---------------------------------------------------------------------------------------------------

/*
#include<iostream>
#include<iomanip>
using namespace std;

//constants
const double ELPR = 94.93;
const double FACTOR = ELPR/100;
const int  FIXEDANNUALCOST = 320;

int main()
{
int monthlyconsumption = 0;
int newmonthlyconsumption = 0;
double cost = 0;
int consumption = 0;
char answer;
do
{
	//load monthly consumption
	system("CLS"); // Clear the screen
	cout << "monthlyconsumption\n";
	cout << "==============\n\n";
	cout << "Input monthlyconsumption : ";
	cin >> monthlyconsumption;
	cout << "newmonthlyconsumption\n";
	cout << "============\n\n";
	cin >> newmonthlyconsumption;
	cin.ignore(80, '\n'); // Skip any possible debris and line endings


	// Calculate cost
	cout << fixed << showpoint;
	consumption = int((newmonthlyconsumption - monthlyconsumption));
		cost = double((consumption) * (FACTOR)+ FIXEDANNUALCOST/12 +0.5);


	// Display results
		cout << "===========================" << endl;
		cout << "total consumption" << setw(6) << consumption << "kwh" << endl;
	cout << "===========================" << endl;
	cout << "calculated cost : " << setw(6) << cost << " kr" << endl;

		cout << "\n\nNew calculation (Y/N)?";
	cin >> answer;
} while (answer == 'Y' || answer == 'y');

return 0;
}
*/
