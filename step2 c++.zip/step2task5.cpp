//STEP2-TASK5-----------------------
/*
#include<iostream>
#include<iomanip>

using namespace std;

int main(void)
{
	int start;
	int stop;
	
	char answer;
	do {
		cout << "enter starting number(1)";
		cin >> start;
		cout << "enter ending number(8)"; //the inputs 1 and 8 make the pattern look like the one in the assignment
		cin >> stop;

		for (int x = start; x <= stop; ++x)
		{
			cout << "*" << "  " << "*" << "  " << "*" << "  " << "*" << "  " << "*" << "  " << "*" << "  " << "  " << endl;
			cout <<" *"<<"  "<<"*"<<"  "<<"*"<<"  "<<"*"<<"  "<<"*"<<"  "<<"*"<<"      "<<"  " << endl;
			
			

		}



		cout << "new calculation(Y/N)?";
		cin >> answer;

	} while (answer == 'Y' || answer == 'y');

	return 0;
}
*/