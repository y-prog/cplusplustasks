
//STEP2TASK7----------------------------------------------------------------------------
// 6,5 7,0 5,0 5,5 6,0 7,5 7,0 6,5 and 4,5 give the final score 6,2.
//Judges figures : 5 5 5 10 5 5 5 2 5 give the final score 5.0

/*
#include <iostream>
#include<iomanip>
#include<cstdio>



using namespace std;

int main()
{



	

	char answer;
	do
	{
	
		double num,
			average,
			sum = 0,
			largest = 0,
			smallest = 0;
	
		
			double count = 1;



			while (count < 10)
			{

				cout << "Number #" << count << ": " << endl;
				cin >> num;



				if (count == 1) {
					largest = num;
					smallest = num;
				}
				else {
					if (num > largest)
						largest = num;
					if (num < smallest)
						smallest = num;
				}

				sum = sum + num;
				count++;


			}




			average = (sum - (largest + smallest)) / (7);


			cout << "The sum of all numbers is " << fixed << setprecision(1) << sum << std::endl;
			cout << "The smallest number is " << fixed << setprecision(1) << smallest << std::endl;
			cout << "The largest number is " << fixed << setprecision(1) << largest << std::endl;
			cout << "The final score is " << fixed << setprecision(1) << average << std::endl;

			cout << "new calculation (Y/N)?";
			cin >> answer;
		
	}
	while (answer == 'Y' || answer == 'y');
	


	return 0;
	


}
*/