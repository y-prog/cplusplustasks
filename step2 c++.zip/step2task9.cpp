//step2task9

/*
#include<iomanip>
#include<iostream>
#include<cmath>

using namespace std;

int main()
{


	
	char answer;
	do {
		int n;
		int numdig;
		int sum = 0;
		int digit = 0;

		cout << "enter a number";
		cin >> n;

		numdig = log10(n) + 1;
		int divisor = pow(10, numdig - 1);


		
		do
		{
			digit = n / divisor;                  

			n = n - (digit * divisor);   

			cout << digit << ' ';

			sum += digit;

			divisor /= 10;                              
		} while (divisor > 0);
		{if (sum > 30 || sum<0) 

		cout << "ERROR-the number is too large or negative" << endl;

		else 
			cout << "\nSum = " << sum << endl;
		}

		cout << "new calculation (Y/N)?";
		cin >> answer;

	} while (answer == 'Y' || answer == 'y');
	
	return 0;




}
*/