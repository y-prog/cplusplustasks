//STEP 2 TASK 1
//===============================================================================================
//PLEASE READ BEFORE STARTING THE CODE 
//BEWARE: given the equation below(2*x-1), in order to be dealing with odd integers, the starting value
//must be an odd number and the stop value must be an even one

//==================================================================================================

/*
#include<iomanip>
#include<iostream>
#include <stdio.h>

using namespace std;

int main()
{
	
	


	char answer;
	do
	{
		int start;
		int stop;
		int product = 1;
		

		cout << "set the initial value(Enter 1 to get 1)";//Enter 1 to get 1 (2*1-1=1; since x=1)
		cin >> start; 
		cout << "set the end value (Enter 8 to get 15)\n\n";//Enter 8 to get 15 (2*8-1=15; snce x =8)
		cin >> stop; 

		


		for (int x = start; x <= stop; ++x)
		{
			
			cout <<int(product=(2*x-1)*product) << endl; 
			printf("%d\n",2 * x - 1);
		}
		printf("\n-------The Product of all integers between 1 and 15 is \n%d", product);

		cout << "----new calculation (Y/N)?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');
		

	return 0;



}
*/