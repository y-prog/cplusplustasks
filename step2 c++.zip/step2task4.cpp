//STEP2-TASK4------------------------------------------

/*

#include<iomanip>
#include<iostream>

using namespace std;

	int main(void)
{
	int start;
	int stop;

	char answer;
	do
	{
		cout << "multiplication table"<< endl;
		cout << "==================" << endl << endl;
		cout << "enter the initial value";
		cin >> start;
		cout << "enter the final value";
		cin >> stop;
		//title
		cout << setw(5) << "x" << setw(10) << "10*x" << setw(10) << "100*x" << setw(10) << "1000*x" << endl;
		cout << "multiplication table" << endl;
		cout << "====================" << endl;


		for (int x = start; x <= stop;++x)
		{
			cout << setw(5) << x << setw(10) << 10 * x << setw(10) << 100 * x << setw(10) << 1000 * x << endl;
		}

		cout << "new calculation (Y/N)?";
		cin >> answer;
	} while (answer == 'Y' || answer == 'y');

	return 0;




}

*/